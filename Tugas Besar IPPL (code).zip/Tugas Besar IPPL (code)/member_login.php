<?php

header('Content-Type: application/json');

// Fungsi validasi input
function validateLoginForm() {
    $errors = [];

    // Validasi email
    if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required";
    }

    // Validasi password
    if (empty($_POST["password"])) {
        $errors[] = "Password is required";
    }

    if (!empty($errors)) {
        echo json_encode([
            'success' => false,
            'errors' => $errors
        ]);
        exit;
    }

    return true;
}

// Proses form login
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (validateLoginForm()) {
        $mysqli = require __DIR__ . "/database.php";

        // Query untuk cek user
        $sql = "SELECT user_id, username, password_hash FROM users WHERE email = ?";
        $stmt = $mysqli->stmt_init();

        if (!$stmt->prepare($sql)) {
            echo json_encode([
                'success' => false,
                'errors' => ['SQL error: ' . $mysqli->error]
            ]);
            exit;
        }

        $stmt->bind_param("s", $_POST["email"]);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if (password_verify($_POST["password"], $user["password_hash"])) {
                session_start();
                $_SESSION["user_id"] = $user["user_id"];
                $_SESSION["username"] = $user["username"]; // Menyimpan username untuk referensi

                // Pencatatan aktivitas login
                $visit_date = date('Y-m-d H:i:s');
                $activity = "login";
                $search_query = "-";  // Kosongkan atau isi dengan "-" karena login tidak melibatkan pencarian
                $user_id = $user["user_id"];
                $username = $user["username"];  // Menyimpan username sesuai user_id

                // Query untuk memasukkan aktivitas ke dalam tabel visitor_reports
                $log_sql = "INSERT INTO visitor_reports (visit_date, activity, search_query, user_id, username) VALUES (?, ?, ?, ?, ?)";
                $log_stmt = $mysqli->stmt_init();

                if (!$log_stmt->prepare($log_sql)) {
                    echo json_encode([
                        'success' => false,
                        'errors' => ['Failed to log activity: ' . $mysqli->error]
                    ]);
                    exit;
                }

                $log_stmt->bind_param("sssis", $visit_date, $activity, $search_query, $user_id, $username);
                $log_stmt->execute();

                echo json_encode(['success' => true]);
            } else {
                echo json_encode([
                    'success' => false,
                    'errors' => ["Invalid email or password"]
                ]);
            }
        } else {
            echo json_encode([
                'success' => false,
                'errors' => ["Invalid email or password"]
            ]);
        }
    }
}
?>
