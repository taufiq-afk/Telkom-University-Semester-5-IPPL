<?php
session_start();
$mysqli = require __DIR__ . "/database.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Debugging 1: Pastikan variabel email dan password diterima
    if (empty($email) || empty($password)) {
        echo json_encode([
            "success" => false,
            "message" => "Email or password cannot be empty",
        ]);
        exit;
    }

    // Query untuk mendapatkan data admin
    $sql = "SELECT * FROM users WHERE email = ? AND role = 'admin'";
    $stmt = $mysqli->prepare($sql);

    // Debugging 2: Pastikan query SQL berhasil dipersiapkan
    if (!$stmt) {
        echo json_encode([
            "success" => false,
            "message" => "SQL Error: " . $mysqli->error,
        ]);
        exit;
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    // Debugging 3: Pastikan data admin ditemukan
    if (!$admin) {
        echo json_encode([
            "success" => false,
            "message" => "Admin not found or email is incorrect",
        ]);
        exit;
    }

    // Debugging 4: Cek apakah password cocok
    if (!password_verify($password, $admin["password_hash"])) {
        echo json_encode([
            "success" => false,
            "message" => "Password is incorrect",
        ]);
        exit;
    }

    // Jika semua validasi lolos
    $_SESSION["admin_id"] = $admin["id"];
    $_SESSION["admin_name"] = $admin["name"];

    echo json_encode(["success" => true]);
    exit;
}
?>
