(function($) {

  "use strict";

  var initPreloader = function() {
    $(document).ready(function($) {
    var Body = $('body');
        Body.addClass('preloader-site');
    });
    $(window).load(function() {
        $('.preloader-wrapper').fadeOut();
        $('body').removeClass('preloader-site');
    });
  }

  // init Chocolat light box
	var initChocolat = function() {
		Chocolat(document.querySelectorAll('.image-link'), {
		  imageSize: 'contain',
		  loop: true,
		})
	}

  var initSwiper = function() {

    var swiper = new Swiper(".main-swiper", {
      loop: true,  // Membuat slide berputar terus-menerus
      autoplay: {
        delay: 3500,  // Slide berpindah otomatis setiap 5 detik
        disableOnInteraction: false,  // Autoplay tetap berjalan meskipun pengguna berinteraksi
      },
      effect: 'slide',  // Menggunakan efek slide untuk perpindahan antar slide
      
      pagination: {
        el: '.swiper-pagination',
        clickable: true,  // Membuat bullet bisa diklik
      },
      speed: 3000,  // Mengatur kecepatan transisi, semakin besar semakin halus (dalam ms)
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
    });

    var bestselling_swiper = new Swiper(".bestselling-swiper", {
      slidesPerView: 4,
      spaceBetween: 30,
      speed: 500,
      breakpoints: {
        0: {
          slidesPerView: 1,
        },
        768: {
          slidesPerView: 3,
        },
        991: {
          slidesPerView: 4,
        },
      }
    });

    var testimonial_swiper = new Swiper(".testimonial-swiper", {
      slidesPerView: 1,
      speed: 500,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
    });

    var products_swiper = new Swiper(".products-carousel", {
      slidesPerView: 4,
      spaceBetween: 30,
      speed: 500,
      breakpoints: {
        0: {
          slidesPerView: 1,
        },
        768: {
          slidesPerView: 3,
        },
        991: {
          slidesPerView: 4,
        },

      }
    });

  }

  var initProductQty = function(){

    $('.product-qty').each(function(){

      var $el_product = $(this);
      var quantity = 0;

      $el_product.find('.quantity-right-plus').click(function(e){
          e.preventDefault();
          var quantity = parseInt($el_product.find('#quantity').val());
          $el_product.find('#quantity').val(quantity + 1);
      });

      $el_product.find('.quantity-left-minus').click(function(e){
          e.preventDefault();
          var quantity = parseInt($el_product.find('#quantity').val());
          if(quantity>0){
            $el_product.find('#quantity').val(quantity - 1);
          }
      });

    });

  }

  // init jarallax parallax
  var initJarallax = function() {
    jarallax(document.querySelectorAll(".jarallax"));

    jarallax(document.querySelectorAll(".jarallax-keep-img"), {
      keepImg: true,
    });
  }

  // document ready
  $(document).ready(function() {
    
    initPreloader();
    initSwiper();
    initProductQty();
    initJarallax();
    initChocolat();

        // product single page
        var thumb_slider = new Swiper(".product-thumbnail-slider", {
          spaceBetween: 8,
          slidesPerView: 3,
          freeMode: true,
          watchSlidesProgress: true,
        });
    
        var large_slider = new Swiper(".product-large-slider", {
          spaceBetween: 10,
          slidesPerView: 1,
          effect: 'fade',
          thumbs: {
            swiper: thumb_slider,
          },
        });

    window.addEventListener("load", (event) => {
      //isotope
      $('.isotope-container').isotope({
        // options
        itemSelector: '.item',
        layoutMode: 'masonry'
      });


      var $grid = $('.entry-container').isotope({
        itemSelector: '.entry-item',
        layoutMode: 'masonry'
      });


      // Initialize Isotope
      var $container = $('.isotope-container').isotope({
        // options
        itemSelector: '.item',
        layoutMode: 'masonry',
        transitionDuration: '0.8s'
      });

      $(document).ready(function () {
        //active button
        $('.filter-button, .categories-item').click(function () {
          $('.filter-button').removeClass('active');
          $(this).addClass('active');
        });
      });

      // Filter items on button click
      $('.filter-button, .categories-item').click(function () {
        var filterValue = $(this).attr('data-filter');
        if (filterValue === '*') {
          // Show all items
          $container.isotope({ filter: '*' });
        } else {
          // Show filtered items
          $container.isotope({ filter: filterValue });
        }
      });

      $('.categories-item').on('click', function (e) {
        e.preventDefault(); // Mencegah tindakan default link
        var target = $(this).attr('href'); // Ambil ID target dari href
        var offset = $(target).offset().top; // Hitung posisi elemen target
        var spaceAbove = 100; // Space tambahan di atas (misalnya 80px)
      
        // Atur scroll tanpa animasi
        $(window).scrollTop(offset - spaceAbove);
      });
      
    });

  }); // End of a document

})(jQuery);

// Register Form
const containerr = document.getElementById('containerr');
const registerBtn = document.getElementById('registerr');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    containerr.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    containerr.classList.remove("active");
});

// Seleksi elemen
let profileDropdownList = document.querySelector(".profile-dropdown-list");
let btn = document.querySelector(".profile-dropdown-btn");
let profileImg = document.querySelector(".profile-img");
let hamburgerCheckbox = document.querySelector(".hamburger input[type='checkbox']");

// Cek jika elemen-elemen ada di DOM
if (profileDropdownList && btn && profileImg && hamburgerCheckbox) {
  // Dapatkan classList dropdown
  let classList = profileDropdownList.classList;

  // Fungsi toggle
  const toggle = () => {
    // Toggle class active pada dropdown
    classList.toggle("active");

    // Menambahkan atau menghapus kelas active untuk efek box-shadow
    profileImg.classList.toggle("active");

    // Jika checkbox ditemukan, toggle checked
    hamburgerCheckbox.checked = !hamburgerCheckbox.checked;
  };

  // Menambahkan event listener pada tombol dropdown
  btn.addEventListener("click", toggle);
}


// Ambil elemen header
const header = document.getElementById("main-header");

// Tambahkan event listener untuk scroll
window.addEventListener("scroll", () => {
  if (window.scrollY > 0) {
    // Tambahkan bayangan saat halaman di-scroll
    header.classList.add("shadow");
  } else {
    // Hapus bayangan jika kembali ke posisi awal
    header.classList.remove("shadow");
  }
});

document.addEventListener("DOMContentLoaded", () => {
  window.scrollTo(0, 0); // Atur posisi scroll ke atas saat halaman dimuat
  
  const header = document.getElementById("main-header");

  window.addEventListener("scroll", () => {
    if (window.scrollY > 0) {
      header.classList.add("shadow");
    } else {
      header.classList.remove("shadow");
    }
  });
});

window.addEventListener("click", function (e) {
  if (!btn.contains(e.target)) classList.remove("active");
});

function openPopup() {
  // Membuka halaman admin_login.html di tab baru
  window.open("admin_login.html", "_blank");
}


// Loop untuk semua gambar dengan class 'image-container'
document.querySelectorAll('.image-container').forEach(function (container) {
  var image = container.querySelector('img'); // Ambil elemen gambar
  var imgUrl = image.getAttribute('data-image'); // Ambil URL gambar dari data-image

  // Menggunakan CSS custom properties untuk mengganti gambar refleksi secara dinamis
  container.style.setProperty('--reflection-image', `url(${imgUrl})`);
});

// Ambil semua elemen dengan class "scroll-button"
document.querySelectorAll('.scroll-button').forEach(button => {
  button.addEventListener('click', function (e) {
    e.preventDefault(); // Mencegah aksi default (scroll langsung)

    const headerHeight = 50; // Ubah sesuai tinggi header Anda
    const targetElement = document.querySelector('#register'); // Selalu mengarah ke #register

    if (targetElement) {
      const targetPosition = targetElement.offsetTop - headerHeight; // Hitung posisi dengan offset header

      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth', // Animasi scroll halus
      });
    }
  });
});

// Pilih tombol yang mengarah ke #exclusive
document.querySelectorAll('.scroll-to').forEach(function(element) {
  element.addEventListener('click', function(e) {
    e.preventDefault(); // Mencegah perilaku default link

    const target = document.querySelector('#exclusive'); // Elemen tujuan
    const offset = 120; // Sesuaikan jarak offset (misalnya, jika ada header)

    // Menambahkan sedikit delay untuk memastikan posisi elemen sudah dihitung
    setTimeout(function() {
      window.scrollTo({
        top: target.getBoundingClientRect().top + window.pageYOffset - offset, // Menambahkan offset
        behavior: 'smooth' // Efek scroll halus
      });
    }, 100); // Delay untuk memberikan waktu sebelum scroll
  });
});





