<?php
// Menyertakan file koneksi database
require_once 'database.php';

// Fungsi untuk menambahkan admin baru
function addAdmin($mysqli, $username, $email, $password) {
    // Mengecek apakah username sudah ada
    $check_sql = "SELECT user_id FROM users WHERE username = ?";
    $check_stmt = $mysqli->prepare($check_sql);
    $check_stmt->bind_param("s", $username);
    $check_stmt->execute();
    $check_stmt->store_result();

    // Jika username sudah ada, tampilkan pesan error dan hentikan eksekusi
    if ($check_stmt->num_rows > 0) {
        echo "Error: Username '$username' sudah digunakan.<br>";
        $check_stmt->close();
        return; // Menghentikan eksekusi jika username sudah ada
    }

    // Hash password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Query untuk menyimpan data admin
    $sql = "INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)";
    $stmt = $mysqli->prepare($sql);

    // Bind parameter
    $role = 'admin';  // Role admin
    $stmt->bind_param("ssss", $username, $email, $password_hash, $role);

    // Eksekusi query
    if ($stmt->execute()) {
        echo "Admin $username berhasil ditambahkan.<br>";
    } else {
        echo "Error: " . $stmt->error . "<br>";
    }

    // Tutup statement
    $stmt->close();
    $check_stmt->close();  // Pastikan juga menutup statement pengecekan username
}

// Menambahkan admin pertama
addAdmin($mysqli, "shalisyhh", "shalisyahaf@gmail.com", "ippl1604");

// Menambahkan admin kedua
addAdmin($mysqli, "fiqquess", "taufikalfikri28@gmail.com", "ippl2804");

// Menambah admin ketiga (komentar atau hapus baris ini jika tidak diperlukan)
// addAdmin($mysqli, "utii", "putriadinda@gmail.com", "praktikan");

// Menutup koneksi
$mysqli->close();
?>
