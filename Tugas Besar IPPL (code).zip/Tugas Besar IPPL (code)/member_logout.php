<?php
session_start(); // Memulai sesi

// Periksa apakah user sudah login
if (isset($_SESSION['user_id'])) {
    $mysqli = require __DIR__ . "/database.php"; // Koneksi ke database

    // Ambil user_id dan username dari sesi
    $user_id = $_SESSION['user_id'];
    $username = $_SESSION['username'];

    // Pencatatan aktivitas logout
    $visit_date = date('Y-m-d H:i:s');
    $activity = "logout";
    $search_query = "-";  // Kosongkan atau isi dengan "-"
    
    // Query untuk memasukkan aktivitas logout ke dalam tabel visitor_reports
    $log_sql = "INSERT INTO visitor_reports (visit_date, activity, search_query, user_id, username) VALUES (?, ?, ?, ?, ?)";
    $log_stmt = $mysqli->stmt_init();

    if (!$log_stmt->prepare($log_sql)) {
        echo json_encode([
            'success' => false,
            'errors' => ['Failed to log activity: ' . $mysqli->error]
        ]);
        exit;
    }

    $log_stmt->bind_param("sssis", $visit_date, $activity, $search_query, $user_id, $username);
    $log_stmt->execute();

    // Hapus semua variabel sesi
    $_SESSION = [];

    // Hapus cookie sesi jika ada
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Hapus sesi
    session_destroy();

    // Kirim respon JSON untuk SweetAlert2
    echo json_encode([
        'success' => true,
        'message' => 'You have been logged out successfully.'
    ]);
    exit;
} else {
    // Kirim respon JSON jika user tidak login
    echo json_encode([
        'success' => false,
        'message' => 'You are not logged in.'
    ]);
    exit;
}
?>
