<?php

function validateForm() {
    $errors = [];
    
    // Validasi username
    if (empty($_POST["username"])) {    
        $errors[] = "Username is required";
    }
    
    // Validasi email
    if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {    
        $errors[] = "Valid email is required";
    }
    
    // Validasi panjang password
    if (strlen($_POST["password"]) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }
    
    // Validasi bahwa password memiliki setidaknya satu huruf
    if (!preg_match("/[a-z]/i", $_POST["password"])) {    
        $errors[] = "Password must contain at least one letter";
    }
    
    // Validasi bahwa password memiliki setidaknya satu angka
    if (!preg_match("/[0-9]/", $_POST["password"])) {    
        $errors[] = "Password must contain at least one number";
    }
    
    // Validasi konfirmasi password
    if ($_POST["password"] !== $_POST["password_confirmation"]) {    
        $errors[] = "Passwords must match";
    }

    // Menampilkan pesan error jika ada kesalahan
    if (!empty($errors)) {
        // Jika ada error, kirim respon JSON dengan error
        echo json_encode([
            'success' => false,
            'errors' => $errors
        ]);
        exit;
    }
    
    return true; // Semua validasi lulus
}

// Memanggil fungsi validateForm() ketika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (validateForm()) {
        // Membuat koneksi ke database jika validasi lulus
        $mysqli = require __DIR__ . "/database.php";

        $sql = "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)";
        
        $stmt = $mysqli->stmt_init();
        
        if (! $stmt->prepare($sql)) {
            echo json_encode([
                'success' => false,
                'errors' => ['SQL error: ' . $mysqli->error]
            ]);
            exit;
        }
        
        $password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT);
        
        $stmt->bind_param("sss",
                          $_POST["username"],
                          $_POST["email"],
                          $password_hash);
                          
        if ($stmt->execute()) {
            // Jika sukses, kirim respon JSON
            echo json_encode([
                'success' => true
            ]);
        } else {
            if ($mysqli->errno === 1062) {
                // Jika ada error dengan username atau email sudah terdaftar
                echo json_encode([
                    'success' => false,
                    'errors' => ['Username or Email already taken']
                ]);
            } else {
                // Jika ada error database lainnya
                echo json_encode([
                    'success' => false,
                    'errors' => ['Database error: ' . $mysqli->error]
                ]);
            }
        }
    }
}
?>
