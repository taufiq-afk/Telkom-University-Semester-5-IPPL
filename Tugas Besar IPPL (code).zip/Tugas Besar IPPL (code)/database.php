<?php

$host = "localhost";
$dbname = "ippl_db";
$username = "root";
$password = "";

// Membuat koneksi ke database
$mysqli = new mysqli($host, $username, $password, $dbname);

// Cek koneksi
if ($mysqli->connect_errno) {
    die("Connection error: " . $mysqli->connect_error);
}

return $mysqli;

?>
