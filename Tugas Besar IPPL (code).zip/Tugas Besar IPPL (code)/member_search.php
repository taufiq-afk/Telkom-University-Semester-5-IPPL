<?php
session_start(); // Memulai sesi

// Periksa apakah user sudah login
if (isset($_SESSION['user_id']) && isset($_POST['search_query'])) {
    $search_query = trim($_POST['search_query']);

    // Pastikan query pencarian tidak kosong
    if (!empty($search_query)) {
        $mysqli = require __DIR__ . "/database.php"; // Koneksi ke database
        
        // Ambil user_id dan username dari sesi
        $user_id = $_SESSION['user_id'];
        $username = $_SESSION['username']; // Pastikan username ada di sesi

        // Pencatatan aktivitas mencari
        $visit_date = date('Y-m-d H:i:s');
        $activity = "mencari";
        
        // Query untuk memasukkan aktivitas pencarian ke dalam tabel visitor_reports
        $log_sql = "INSERT INTO visitor_reports (visit_date, activity, search_query, user_id, username) VALUES (?, ?, ?, ?, ?)";
        $log_stmt = $mysqli->stmt_init();

        if (!$log_stmt->prepare($log_sql)) {
            echo json_encode([
                'success' => false,
                'errors' => ['Failed to log search activity: ' . $mysqli->error]
            ]);
            exit;
        }

        // Menyisipkan data pencarian ke dalam database
        $log_stmt->bind_param("sssis", $visit_date, $activity, $search_query, $user_id, $username);
        $log_stmt->execute();

        echo json_encode([
            'success' => true,
            'message' => 'Search activity recorded successfully.'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Search query cannot be empty.'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'User is not logged in or invalid request.'
    ]);
}
?>
